SHEM KATZ — LIGHTROOM PRESETS
78 develop presets in nine groups.


INSTALLING
----------
Lightroom Classic:  File > Import Develop Profiles & Presets…  and select the
                    zip. The groups appear in the Presets panel as SK Underwater,
                    SK Land & Street, SK Black & White, SK Commercial, SK Retro,
                    SK Vintage, SK 35mm Colour, SK 35mm Mono, SK Street Colour,
                    SK Street Mono and SK Utility.

Lightroom (cloud):  Edit > Presets > three-dot menu > Import Presets…
Camera Raw:         Presets tab > three-dot menu > Import.


HOW THEY ARE BUILT
------------------
Each preset carries only the sliders it needs, so they stack: apply a look,
add a Utility preset on top, and the look survives.

White balance is deliberately never set. Correct temperature depends on depth,
strobes and time of day, and a preset that forces a Kelvin value ruins more
frames than it saves. Set white balance first, then apply the preset.

The colour film, retro and street groups lean on per-channel tone curves,
because that is where film character actually lives — lifting the blue
channel's shadows while rolling off its highlights gives the cool-shadow,
warm-highlight crossover that reads as "film" far more convincingly than
saturation ever will.


THE GROUPS
----------
SK UNDERWATER (6)
  Blue Water Rescue, Deep Ambient, Strobe Night Dive, Reef Colour Pop,
  Over-Under Balance, Macro on Black.
  Blue Water Rescue is the everyday one: saturation out of the aqua and blue
  bands, reds and oranges back up, shadows lifted, a little dehaze.

SK LAND & STREET (7)
  Warm Negative, Tropical Daylight, Golden Hour, Overcast Lift, Faded Matte,
  Muted Green, Portrait Soft Warm.

SK BLACK & WHITE (4)
  Mono High Contrast, Mono Classic Film, Mono Underwater, Mono Street Grain.

SK COMMERCIAL (5)
  Interior Natural, Interior Twilight, Event Low Light, Product Clean,
  Food Warm.

SK RETRO (6)
  Sun-Bleached 70s, Warm Fade 80s, Instant Print, Neon Night, Super 8,
  Teal & Orange. Stylised rather than faithful — the point is the era, not
  accuracy.

SK VINTAGE (6)
  Aged Print, Sepia Wash, Cyanotype, Dusty Archive, Faded Postcard,
  Antique Portrait. Older and more degraded than Retro: yellowed paper,
  toned monochrome, heavy grain, deep vignettes.

SK 35mm COLOUR (8)
  Portrait Negative 400   Warm skin, soft contrast, muted greens, fine grain.
  Consumer Negative 200   Punchier and yellower, the everyday drugstore roll.
  Pro Negative 160        Low contrast, pastel, neutral skin.
  Saturated Slide 50      Dense shadows, deep reds and greens, high contrast.
  Neutral Slide 100       Clean transparency look, moderate contrast.
  Cinema Negative 250D    Teal shadows, warm highlights, low contrast.
  Cross Process           Cyan shadows, yellow highlights, hard contrast.
  Expired Roll            Magenta shift, washed blacks, coarse grain.

SK 35mm MONO (8)
  Mono 100 Fine Grain, Mono 400 Classic, Mono 400 Pushed, Mono 3200 Grainy,
  plus four contrast-filter emulations — Red (dramatic skies), Orange,
  Yellow (subtle sky separation) and Green (foliage and skin).

SK STREET COLOUR (12)
  Muted Chrome, Chrome Punch, Chrome Fade, City Neutral, Warm Pavement,
  Cool Pavement, Nostalgic Amber, Muted Negative, Deep Shadow Street,
  Pastel Street, Evening Gold, Rain and Concrete.

SK STREET MONO (8)
  Neutral, Contrast, Fade, Pushed, Low Key, High Key, Cool Tone, Warm Tone.

SK UTILITY (8)
  Dehaze Lift, Noise Clean, Fine Grain, Heavy Grain, Vignette Soft,
  Sharpen for Web, Matte Finish, Deep Lift. Stack these on top of a look.


ON THE STREET AND FILM GROUPS
-----------------------------
These are named for what they do rather than after film stocks or camera
makers. The looks are reconstructed from sliders — the names belong to Kodak,
Fuji and Ilford and I would rather not put someone else's brand on your work.

Worth knowing: Fuji's film simulations are in-camera JPEG renderings, and
Adobe's camera-matching profiles for them only apply to Fuji raw files. Your
Olympus and Sony raws cannot use those profiles at all, so the Street groups
rebuild the look with sliders instead — muted yellows and greens, honest reds,
cooled shadows, contrast held in the midtones rather than the ends.


EXPECTATIONS
------------
A preset is a starting point. These were written for the kinds of files you
shoot but not against your camera's specific colour science, and they have not
been rendered through Lightroom — I can write the numbers but I cannot see the
result. Expect to nudge exposure and white balance on every image, and to ease
off saturation on anything already vivid. If one consistently lands in the same
wrong place, say which slider and by how much and I will rebuild it.
